/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul.pkg5;
import java.awt.Color;
/**
 *
 * @author USER
 */
public class Kucing2 {
        public String nama;
	public Color warnaBulu;
	public int usia;
	public double bb;
	public boolean statusJinak;
	public String majikan;

	public void cetakInformasi(){
System.out.println("Kucing bernama : "+nama);
System.out.println("Warna Bulu : "+warnaBulu);
System.out.println("Usia : "+usia);
System.out.println("Berat Badan : "+bb);
System.out.println("Jinak ? "+apakahJinak());
System.out.println("Diadopsi oleh : "+majikan);

	}

	public void diadopsi (String m) {
majikan = m;
statusJinak = true;

	}

	public boolean apakahJinak(){
		return statusJinak;
	}
	
	public void dilepas(){
majikan = " ";
statusJinak = false;
	}
 
}
