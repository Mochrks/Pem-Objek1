/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul.pkg5;
import java.lang.*;
/**
 *
 * @author USER
 */
public class TestPerson {
  public static void main (String [] args ){
		Person2 eka = new Person2();
		eka.name="Auliya Eka";
		eka.gender='L';
		eka.age=20;
		eka.dateOfBirth="Bandung, 05 Oktober 1999";
		eka.address="Komplek Gading Tutuka 2";
		eka.height=178;
		eka.weight=70;
		
		eka.cetakBiodata(eka.name, eka.gender, eka.address);
		eka.cetakFisik(eka.age, eka.dateOfBirth, eka.height, eka.weight);
		
	}

}
