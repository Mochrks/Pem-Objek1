/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul.pkg5;
import java.awt.Color;

/**
 *
 * @author USER
 */
public class LingkunganRumah {
public static void main (String args[]){
Kucing michael = new Kucing( );
Kucing garfield = new Kucing( );
michael.warnaBulu = new Color (0 , 1 , 1);
michael.nama = "Michael";
michael.usia = 3;
michael.bb = 4.5;
michael.diadopsi("Rezki");
//some code

}
 
}
