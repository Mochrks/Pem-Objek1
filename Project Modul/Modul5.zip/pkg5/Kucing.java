/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul.pkg5;
import java.awt.Color;

/**
 *
 * @author USER
 */
public class Kucing {
public String nama;
public Color warnaBulu;
public int usia;
public double bb;
public boolean statusJinak;
public String majikan;
public void cetakInformasi( ){
//some code
}
public void diadopsi (String m) {
//some code


}
public boolean apakahJinak( ) {
return statusJinak;
}
public void dilepas( ) {
//some code

}
 
}
