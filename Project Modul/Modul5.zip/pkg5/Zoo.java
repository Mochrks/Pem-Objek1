/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul.pkg5;
import java.awt.Color;
/**
 *
 * @author USER
 */
public class Zoo {
    public static void main (String args[]){
		Lion singa = new Lion ();
		Horse kuda = new Horse ();
		Kangoroo kangguru = new Kangoroo ();
 		
		singa.warnaBulu = new Color (0, 1, 1);
		singa.nama = "Singa";
                singa.asal = "Afrika";
		singa.usia = 11;
		singa.bb = 190;
		singa.diadopsi ("Eka");
		
		kuda.warnaBulu = new Color (0, 1, 1);
		kuda.nama = "Kuda";
                kuda.asal = "Afrika";
		kuda.usia = 20;
		kuda.bb = 380;
		kuda.diadopsi ("Eka");

		kangguru.warnaBulu = new Color (0, 1, 1);
		kangguru.nama = "Kangguru";
		kangguru.asal = "Australia";
                kangguru.usia = 9;
		kangguru.bb = 45;
		kangguru.diadopsi ("Eka");
                singa.cetakInformasi();
		kuda.cetakInformasi();
		kangguru.cetakInformasi();
	}

}
