/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul.pkg5;

/**
 *
 * @author USER
 */
public class GradeBookTest {
    public static void main (String args[]){
GradeBook myGradeBook = new GradeBook();
myGradeBook.displayMessage();
}
}
